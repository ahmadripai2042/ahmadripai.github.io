# Ken_Portfolio
A data science portfolio of Ken Jee.
